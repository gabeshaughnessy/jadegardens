<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, WordPress Language, and ABSPATH. You can find more information
 * by visiting {@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */
if ( file_exists( dirname( __FILE__ ) . '/local-config.php' ) ) {
  include( dirname( __FILE__ ) . '/local-config.php' );
  define( 'WP_LOCAL_DEV', true ); 
	
 } else {
// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'gabesima_jadegardenswp1');

/** MySQL database username */
define('DB_USER', 'gabesima_jazen');

/** MySQL database password */
define('DB_PASSWORD', 'Jad3Gard3n$');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '1m:`2c|Zqnyq(-q`Y0=i5^2+CfRkhV<tf/0[]1|[XBM}aPC=s61W8D0UEUhna=Rn');
define('SECURE_AUTH_KEY',  'jV?}-A>Q|9X! F~i#{@2`;=6Rz6<+l fN1/,4<:@Biu:hLGL:r,3S1mZ1qzNs FL');
define('LOGGED_IN_KEY',    'k3WUK$+D4>SSF0$p2fV;JIcq20a$5h< tj=5`Xqh&ox>:s#%yQQ.sYP!H]i*i{~|');
define('NONCE_KEY',        'LKP&.jn;AaOe.c RL(N,E=<O-a33`E$5ODY=fU.L+{<M,:[z4%ZV[]hZieMe?N/-');
define('AUTH_SALT',        'QXKVb<|;-mk{E|mk(-|9&Y@m_E8>$(HoK!=4|+ikjtqlzyBedVE]L8q#&b:-<-Z(');
define('SECURE_AUTH_SALT', '.$fgZFLL4u>WQ<C<^G>bm-J#DQ{^eR2`B{rcG~+JSXL-+ux=#<3)F#!yVY@:+7@:');
define('LOGGED_IN_SALT',   '4j]-PSPh|=0l&im>4M<KSBq-#t c:V=|F|H:>D26u/t.fH$KM=r$&vjMv`}M(P-*');
define('NONCE_SALT',       'ulh55zSk3UR]o}J7_o]0&u>CNLsE|.9YN[0Ad]+OxG)3FuaPBw&87q7[2FI8 78!');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * WordPress Localized Language, defaults to English.
 *
 * Change this to localize WordPress. A corresponding MO file for the chosen
 * language must be installed to wp-content/languages. For example, install
 * de_DE.mo to wp-content/languages and set WPLANG to 'de_DE' to enable German
 * language support.
 */
define('WPLANG', '');

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
}
